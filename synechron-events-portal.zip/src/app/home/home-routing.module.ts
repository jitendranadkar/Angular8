import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { SepHomeComponent } from "./sep-home/sep-home.component";

const homeRoutes: Routes = [
  {
    path: "",
    component: SepHomeComponent,
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(homeRoutes)],
})
export class HomeRoutingModule {}
