import { Component, OnInit } from "@angular/core";
import { UserService } from "../services/user.service";
import { User } from "../models/user";

@Component({
  selector: "user-list",
  templateUrl: "./user-list.component.html",
  styleUrls: ["./user-list.component.css"],
})
export class UserListComponent implements OnInit {
  constructor(private _userService: UserService) {}

  title: string = "JSon placeholder's User Data !";
  users: User[] = [];

  ngOnInit() {
    this._userService
      .getAllUsers()
      .subscribe(
        data => (
          (this.users = data),
          err => console.log(err),
          () => console.log("Service call completed !")
        ),
      );
  }
}
