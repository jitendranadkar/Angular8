import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { UserListComponent } from "./user-list/user-list.component";
import { UserService } from "./services/user.service";
import { UsersRoutingModule } from './users-routing.module';

@NgModule({
  declarations: [UserListComponent],
  imports: [CommonModule, HttpClientModule, FormsModule, UsersRoutingModule],
  providers: [UserService],
  exports: [UserListComponent],
})
export class UsersModule {}
