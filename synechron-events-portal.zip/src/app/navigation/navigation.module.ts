import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule } from "@angular/router";

import { SepMenuComponent } from "./sep-menu/sep-menu.component";

@NgModule({
  declarations: [SepMenuComponent],
  imports: [CommonModule, RouterModule],
  exports: [SepMenuComponent],
})
export class NavigationModule {}
