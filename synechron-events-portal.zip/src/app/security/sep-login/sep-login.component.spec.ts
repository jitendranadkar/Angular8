import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SepLoginComponent } from './sep-login.component';

describe('SepLoginComponent', () => {
  let component: SepLoginComponent;
  let fixture: ComponentFixture<SepLoginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SepLoginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SepLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
