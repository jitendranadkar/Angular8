import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { SepLoginComponent } from "./sep-login/sep-login.component";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

@NgModule({
  declarations: [SepLoginComponent],
  imports: [CommonModule, FormsModule, HttpClientModule],
  exports: [SepLoginComponent],
})
export class SecurityModule {}
