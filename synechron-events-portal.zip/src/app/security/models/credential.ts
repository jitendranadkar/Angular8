export class Credential {
  constructor() {}
  name: string;
  password: string;
}
