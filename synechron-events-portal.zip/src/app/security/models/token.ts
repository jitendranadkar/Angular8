export class Token {
  constructor() {}
  success: boolean;
  token: string;
}
