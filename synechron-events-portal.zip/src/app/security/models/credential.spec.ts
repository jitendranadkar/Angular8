import { Credential } from './credential';

describe('Credential', () => {
  it('should create an instance', () => {
    expect(new Credential()).toBeTruthy();
  });
});
