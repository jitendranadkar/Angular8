import { TestBed } from '@angular/core/testing';

import { SepAuthService } from './sep-auth.service';

describe('SepAuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SepAuthService = TestBed.get(SepAuthService);
    expect(service).toBeTruthy();
  });
});
