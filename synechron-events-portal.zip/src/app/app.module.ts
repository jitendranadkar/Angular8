import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
//import { FormsModule } from "@angular/forms";
//import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
// import { EmployeesModule } from "./employees/employees.module";
// import { EventsModule } from "./events/events.module";
// import { JphModule } from "./jph/jph.module";
// import { UsersModule } from "./users/users.module";
import { NavigationModule } from "./navigation/navigation.module";
import { FooterModule } from "./footer/footer.module";
import { SecurityModule } from "./security/security.module";
//import { HomeModule } from "./home/home.module";

//import { SepHomeComponent } from './home/sep-home/sep-home.component';
//import { FooterComponent } from './footer/footer/footer.component';
//import { SepMenuComponent } from "./navigation/sep-menu/sep-menu.component";
//import { EmployeesListComponent } from "./employees/employees-list/employees-list.component";
//import { EmployeeDetailsComponent } from "./employees/employee-details/employee-details.component";
//import { EventsListComponent } from "./events/events-list/events-list.component";
//import { EventDetailsComponent } from "./events/event-details/event-details.component";
//import { CapitalizeLetterPipe } from "./events/pipes/capitalize-letter.pipe";
//import { FilterByPipe } from "./events/pipes/filter-by.pipe";
//import { FilterByEmpNamePipe } from "./employees/pipes/filter-by-emp-name.pipe";
//import { PostListComponent } from "./jph/post-list/post-list.component";
//import { HttpClient } from "selenium-webdriver/http";
//import { UserListComponent } from "./users/user-list/user-list.component";

@NgModule({
  declarations: [
    AppComponent,
    //SepHomeComponent,
    //FooterComponent,
    //SepMenuComponent,
    //EmployeesListComponent,
    // EmployeeDetailsComponent,
    // EventsListComponent,
    // EventDetailsComponent,
    // CapitalizeLetterPipe,
    // FilterByPipe,
    //FilterByEmpNamePipe,
    //PostListComponent,
    //UserListComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    //EmployeesModule,
    //EventsModule,
    //JphModule,
    //UsersModule,
    NavigationModule,
    FooterModule,
    //HomeModule,
    SecurityModule,
  ], // FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
