import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from "@angular/forms";

import { PostListComponent } from "./post-list/post-list.component";
import { JphService } from "./services/jph.service";
import { JphRoutingModule } from './jph-routing.module';

@NgModule({
  declarations: [PostListComponent],
  imports: [CommonModule, HttpClientModule, FormsModule, JphRoutingModule],
  providers: [JphService],
  exports: [PostListComponent],
})
export class JphModule {}
