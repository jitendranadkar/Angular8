import { Component, OnInit } from "@angular/core";
import { JphService } from "../services/jph.service";
import { Post } from "../models/post";

@Component({
  selector: "post-list",
  templateUrl: "./post-list.component.html",
  styleUrls: ["./post-list.component.css"],
})
export class PostListComponent implements OnInit {
  constructor(private _jphService: JphService) {}
  title: string = "JSon placeholder's Posts Data !";
  posts: Post[] = [];

  ngOnInit(): void {
    this._jphService
      .getAllPosts()
      .subscribe(
        data => (
          (this.posts = data),
          err => console.log(err),
          () => console.log("Service call completed !")
        ),
      );
  }
}
