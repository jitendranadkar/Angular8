import { Syneevent } from './syneevent';

describe('Syneevent', () => {
  it('should create an instance', () => {
    expect(new Syneevent()).toBeTruthy();
  });
});
