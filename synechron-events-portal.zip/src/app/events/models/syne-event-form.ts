import { FormGroup, FormControl, Validators } from "@angular/forms";

export class Syneeventform {
  constructor() {}

  eventForm: FormGroup = new FormGroup({
    eventId: new FormControl(0, Validators.required),
    eventCode: new FormControl("NA", [
      Validators.required,
      Validators.maxLength(6),
      Validators.minLength(6),
    ]),
    eventName: new FormControl("NA", [
      Validators.required,
      Validators.maxLength(50),
    ]),
    description: new FormControl(undefined),
    startDate: new FormControl(new Date()),
    endDate: new FormControl(new Date()),
    fees: new FormControl(0),
    seatsFilled: new FormControl(0, [Validators.min(0), Validators.max(100)]),
  });
}
