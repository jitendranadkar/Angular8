import { Component, Input, OnChanges, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Syneevent } from "../models/syneevent";
import { EventsService } from "../services/events.service";

@Component({
  selector: "event-details",
  templateUrl: "./event-details.component.html",
  styleUrls: ["./event-details.component.css"],
})
export class EventDetailsComponent implements OnInit {
  ngOnInit(): void {
    //this.syneevent = this._eventsService.getEventDetails(this.eventId);
    let eventId = this._activatedRoute.snapshot.paramMap.get("eventId");
    this._eventsService
      .getEventDetails(Number.parseInt(eventId))
      .subscribe(
        data => (this.syneevent = data),
        err => console.log(err),
        () => console.log(),
      );
  }

  constructor(
    private _eventsService: EventsService,
    private _activatedRoute: ActivatedRoute,
  ) {}

  title: string = "Details of - ";
  //@Input("syneEventId") eventId: number;
  syneevent: Syneevent;
  // @Output("onChildNotification") notification: EventEmitter<
  //   string
  // > = new EventEmitter<string>();
  // onNotificationSend(): void {
  //   this.notification.emit("Employee data recieved successfully !!!");
  // }
}
