import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";

import { EventsListComponent } from "./events-list/events-list.component";
import { RegisterEventComponent } from "./register-event/register-event.component";
import { EventDetailsComponent } from "./event-details/event-details.component";
import { AuthService } from "./services/auth.service";

const eventRoutes: Routes = [
  {
    path: "",
    component: EventsListComponent,
    canActivate: [AuthService],
  },
  {
    path: "new",
    component: RegisterEventComponent,
    canActivate: [AuthService],
  },
  {
    path: ":id",
    component: EventDetailsComponent,
    canActivate: [AuthService],
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(eventRoutes)],
})
export class EventsRoutingModule {}
