import { Component, OnInit } from "@angular/core";
import { Syneevent } from "../models/syneevent";
import { EventsService } from "../services/events.service";

@Component({
  selector: "events-list",
  templateUrl: "./events-list.component.html",
  styleUrls: ["./events-list.component.css"],
})
export class EventsListComponent implements OnInit {
  ngOnInit(): void {
    this._eventsService
      .getAllEvents()
      .subscribe(
        data => (this.Syneevents = data),
        err => console.log(err),
        () => console.log("Events REST service call is completed..."),
      );
  }
  constructor(private _eventsService: EventsService) {}
  title: string = "Synechron Event List !";
  subtitle: string = "Core Development Team !";
  searchChar: string = "";
  //selectedEvent: Syneevent;
  selectedEventId: number;
  childMessage: string;
  receiveChildConfirmation(message: string): void {
    this.childMessage = message;
  }
  //employee: Employee;

  Syneevents: Syneevent[] = [];

  onEventSelection(syneeventId: number): void {
    this.selectedEventId = syneeventId;
    //console.log(this.selectedEvent);
  }
}
