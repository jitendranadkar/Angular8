import { Injectable } from "@angular/core";
import {
  HttpInterceptor,
  HttpEvent,
  HttpHandler,
  HttpRequest,
  HttpHeaders,
} from "@angular/common/http";
import { Observable } from "rxjs";

import { Token } from "../../security/models/token";

@Injectable({ providedIn: "root" })
export class AuthTokenInterceptor implements HttpInterceptor {
  authtoken: Token;

  getToken(): string {
    this.authtoken = <Token>JSON.parse(sessionStorage.getItem("token"));
    return this.authtoken.token;
  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler,
  ): Observable<HttpEvent<any>> {
    const authReq = req.clone({
      headers: new HttpHeaders({
        "content-type": "application/json",
        "x-access-token": this.getToken(),
      }),
    });
    return next.handle(authReq);
  }
}
