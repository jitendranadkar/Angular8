import { Pipe, PipeTransform } from "@angular/core";
import { WrappedNodeExpr } from "@angular/compiler";

@Pipe({
  name: "capitalizeLetter",
})
export class CapitalizeLetterPipe implements PipeTransform {
  transform(value: any, ...args: any[]): any {
    if (!value) return value;
    return value.replace(
      /\w\S*/g,
      word =>
        word.charAt(0).toLocaleUpperCase() + word.substr(1).toLocaleLowerCase(),
    );
  }
}
