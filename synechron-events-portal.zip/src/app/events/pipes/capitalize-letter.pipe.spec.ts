import { CapitalizeLetterPipe } from './capitalize-letter.pipe';

describe('CapitalizeLetterPipe', () => {
  it('create an instance', () => {
    const pipe = new CapitalizeLetterPipe();
    expect(pipe).toBeTruthy();
  });
});
