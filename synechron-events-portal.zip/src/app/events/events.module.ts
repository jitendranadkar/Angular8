import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { EventsListComponent } from "./events-list/events-list.component";
import { EventDetailsComponent } from "./event-details/event-details.component";
import { CapitalizeLetterPipe } from "./pipes/capitalize-letter.pipe";
import { FilterByPipe } from "./pipes/filter-by.pipe";
import { EventsService } from "./services/events.service";
import { RegisterEventComponent } from "./register-event/register-event.component";
import { RouterModule } from "@angular/router";
import { EventsRoutingModule } from "./events-routing.module";
import { AuthService } from "./services/auth.service";
import { AuthTokenInterceptor } from "./services/auth-token.interceptor";

@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    CapitalizeLetterPipe,
    FilterByPipe,
    RegisterEventComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    RouterModule,
    ReactiveFormsModule,
    EventsRoutingModule,
  ],
  providers: [
    EventsService,
    AuthService,
    { provide: HTTP_INTERCEPTORS, useClass: AuthTokenInterceptor, multi: true },
  ],
  exports: [EventsListComponent, RegisterEventComponent],
})
export class EventsModule {}
