import { Component } from "@angular/core";
import { Router } from "@angular/router";

import { Syneeventform } from "../models/syne-event-form";
import { EventsService } from "../services/events.service";
@Component({
  selector: "register-event",
  templateUrl: "./register-event.component.html",
  styleUrls: ["./register-event.component.css"],
})
export class RegisterEventComponent {
  constructor(private _eventsService: EventsService, private _router: Router) {}
  title: string = "Register Upcoming Synechron Event !!!";
  newEvent: Syneeventform = new Syneeventform();

  onNewEventSubmit(): void {
    console.log(this.newEvent.eventForm.value);
    this._eventsService
      .registerNewEvent(this.newEvent.eventForm.value)
      .subscribe(
        data => console.log(data),
        err => console.log(err),
        () => {
          this._router.navigate(["/events"]);
        },
      );
  }
}
