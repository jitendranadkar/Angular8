import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";

import { EmployeesListComponent } from "./employees-list/employees-list.component";
import { EmployeeDetailsComponent } from "./employee-details/employee-details.component";
import { FilterByEmpNamePipe } from "./pipes/filter-by-emp-name.pipe";
import { EmployeesRoutingModule } from "./employees-routing.module";

@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeeDetailsComponent,
    FilterByEmpNamePipe,
  ],
  imports: [CommonModule, FormsModule, EmployeesRoutingModule],
  exports: [EmployeesListComponent],
})
export class EmployeesModule {}
