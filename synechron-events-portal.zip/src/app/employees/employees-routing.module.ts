import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { RouterModule, Routes } from "@angular/router";
import { EmployeesListComponent } from "./employees-list/employees-list.component";

const employeeRoutes: Routes = [
  {
    path: "",
    component: EmployeesListComponent,
  },
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(employeeRoutes)],
  exports: [RouterModule],
})
export class EmployeesRoutingModule {}
