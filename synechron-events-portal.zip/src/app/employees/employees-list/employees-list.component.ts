import { Component } from "@angular/core";
import { Employee } from "../models/employee";

@Component({
  selector: "employees-list",
  templateUrl: "./employees-list.component.html",
  styleUrls: ["./employees-list.component.css"],
})
export class EmployeesListComponent {
  constructor() {
    // this.employee = new Employee();
    // this.employee.employeeName = "Jitendra Nadkar";
    // this.employee.city = "Pune";
    // this.employee.email = "jitendra.nadkar@synechron.com";
    // this.employee.phone = "8390978113";
  }
  title: string = "Synechron Employees List !";
  subtitle: string = "Core Development Team !";
  searchChars: string = "";
  selectedEmployee: Employee;
  childMessage: string;
  searchChars1: string = "";
  receiveChildConfirmation(message: string): void {
    this.childMessage = message;
  }
  //employee: Employee;

  employees: Employee[] = [
    {
      employeeId: 21399,
      employeeName: "Jitendra Nadkar",
      address: "Blue Ridge, 3001/23",
      city: "Pune",
      zipcode: 411051,
      phone: "+91 8390978113",
      email: "jitendra.nadkar@synechron.com",
      skillSets: "Microsoft/MVC",
      country: "India",
      avatar: "images/noimage.png",
    },
    {
      employeeId: 2370,
      employeeName: "Pravinkumar R. D.",
      address: "Suncity, A8/404",
      city: "Pune",
      zipcode: 411051,
      phone: "+91 23892893",
      email: "pravin.r.d@synechron.com",
      skillSets: "Microsoft/JavaScript",
      country: "India",
      avatar: "images/noimage.png",
    },
    {
      employeeId: 2372,
      employeeName: "Manish Kaushik",
      address: "Mooncity, Z8/404",
      city: "Raipur",
      zipcode: 459899,
      phone: "+91 9039039090",
      email: "manish.kaushik@synechron.com",
      skillSets: "DBA",
      country: "India",
      avatar: "images/noimage.png",
    },
    {
      employeeId: 2374,
      employeeName: "Alisha C.",
      address: "Mooncity, B8/404",
      city: "Mumbai",
      zipcode: 510512,
      phone: "+91 30003000",
      email: "alisha.c@synechron.com",
      skillSets: "Java",
      country: "India",
      avatar: "images/noimage.png",
    },
  ];

  onEmployeeSelection(employee: Employee): void {
    this.selectedEmployee = employee;
    this.searchChars = "";
    console.log(this.selectedEmployee);
  }
}
