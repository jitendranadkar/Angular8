import { FilterByEmpNamePipe } from './filter-by-emp-name.pipe';

describe('FilterByEmpNamePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByEmpNamePipe();
    expect(pipe).toBeTruthy();
  });
});
