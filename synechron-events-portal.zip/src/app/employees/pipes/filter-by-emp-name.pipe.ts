import { Pipe, PipeTransform } from "@angular/core";
import { Employee } from "../models/employee";

@Pipe({
  name: "filterByEmpName",
})
export class FilterByEmpNamePipe implements PipeTransform {
  transform(value: Employee[], ...args: string[]): Employee[] {
    let filter: string = args[0] ? args[0].toLocaleLowerCase() : null;
    return filter
      ? value.filter(event =>
          event.employeeName.toLocaleLowerCase().startsWith(filter),
        )
      : value;
  }
}
