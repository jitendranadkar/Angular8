import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SepLoginComponent } from "./security/sep-login/sep-login.component";
// import { SepHomeComponent } from "./home/sep-home/sep-home.component";
// import { EmployeesListComponent } from "./employees/employees-list/employees-list.component";
// import { EventsListComponent } from "./events/events-list/events-list.component";
// import { PostListComponent } from "./jph/post-list/post-list.component";
// import { UserListComponent } from "./users/user-list/user-list.component";
// import { EventDetailsComponent } from "./events/event-details/event-details.component";
// import { RegisterEventComponent } from "./events/register-event/register-event.component";

const homeRoutes: Routes = [
  {
    path: "home",
    //loadChildren: "./home/home.module.#HomeModule", // Ang 2 to 7 Syntax
    loadChildren: () => import("./home/home.module").then(m => m.HomeModule),
  },
];

const eventRoutes: Routes = [
  {
    path: "events",
    loadChildren: () =>
      import("./events/events.module").then(m => m.EventsModule),
  },
];

const employeesRoutes: Routes = [
  {
    path: "employees",
    loadChildren: () =>
      import("./employees/employees.module").then(m => m.EmployeesModule),
  },
];

const jphRoutes: Routes = [
  {
    path: "posts",
    loadChildren: () => import("./jph/jph.module").then(m => m.JphModule),
  },
];

const usersRoutes: Routes = [
  {
    path: "users",
    loadChildren: () => import("./users/users.module").then(m => m.UsersModule),
  },
];

const securityRoutes: Routes = [
  {
    path: "login",
    component: SepLoginComponent,
  },
];

const defaultRoutes: Routes = [
  {
    path: "",
    loadChildren: () => import("./home/home.module").then(m => m.HomeModule),
  },
];

const routes: Routes = [
  ...homeRoutes,
  ...employeesRoutes,
  ...eventRoutes,
  ...jphRoutes,
  ...usersRoutes,
  ...defaultRoutes,
  ...securityRoutes,
  // {
  //   path: "",
  //   component: SepHomeComponent,
  // },
  // {
  //   path: "home",
  //   component: SepHomeComponent,
  // },
  // {
  //   path: "employees",
  //   component: EmployeesListComponent,
  // },
  // {
  //   path: "events",
  //   component: EventsListComponent,
  // },
  // {
  //   path: "events/new",
  //   component: RegisterEventComponent,
  // },
  // {
  //   path: "events/:eventId",
  //   component: EventDetailsComponent,
  // },
  // {
  //   path: "jph/posts",
  //   component: PostListComponent,
  // },
  // {
  //   path: "users",
  //   component: UserListComponent,
  // },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
